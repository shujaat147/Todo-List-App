import AddTask from "./components/AddTask";
import TodoList from "./components/TodoList";

const App = () => {
  return (
    <div className="container">
      <div className="mt-3">
        <div className="row">
          <div className="col">
            <AddTask />
          </div>
          <div className="col">
            <TodoList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
