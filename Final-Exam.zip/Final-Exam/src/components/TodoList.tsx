import React from "react";

interface Task {
  id: number;
  priority: "high" | "medium" | "low";
  taskName: string;
  taskDetails: string;
  date: string;
  finished: boolean;
}

interface TodoListProps {
  tasks: Task[];
  finishTask: (id: number) => void;
  deleteTask: (id: number) => void;
}

const TodoList: React.FC<TodoListProps> = ({
  tasks,
  finishTask,
  deleteTask,
}) => {
  const pendingTasksCount = tasks.filter((task) => !task.finished).length;

  const getPriorityColor = (priority: "high" | "medium" | "low") => {
    switch (priority) {
      case "high":
        return "bg-danger text-white";
      case "medium":
        return "bg-warning text-dark";
      case "low":
        return "bg-success text-dark";
      default:
        return "";
    }
  };

  const handleFinishTask = (id: number) => {
    finishTask(id);
  };

  const handleDeleteTask = (id: number) => {
    deleteTask(id);
  };

  return (
    <div>
      <table className="table-bordered text-center table-sm">
        <h1 className="text-primary">Add Your Task</h1>
        <h3 className="mb-4">Pending Tasks: {pendingTasksCount}</h3>
        <hr />
        <tbody>
          {tasks.map((task, index) => (
            <tr
              key={task.id}
            >
              <td><button className={`btn rounded-circle ${getPriorityColor(task.priority)}`}>{index + 1}</button></td>
              <td>
                {task.taskName}
                <br />
                <small>{task.date}</small>
              </td>
              <td>{task.taskDetails}</td>
              <td>
                <div className="form-check form-switch">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id={`finish-${task.id}`}
                    checked={task.finished}
                    onChange={() => handleFinishTask(task.id)}
                  />
                  <label
                    className="form-check-label"
                    htmlFor={`finish-${task.id}`}
                  >
                    {task.finished ? "Finished" : "Finish"}
                  </label>
                </div>
                <button
                  className="btn text-danger"
                  onClick={() => handleDeleteTask(task.id)}
                >
                  &#10005;
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TodoList;
